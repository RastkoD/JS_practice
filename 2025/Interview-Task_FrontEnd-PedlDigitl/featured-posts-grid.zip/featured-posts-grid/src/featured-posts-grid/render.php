<?php

if ( empty( $attributes['postIds'] ) || ! is_array( $attributes['postIds'] ) ) {
    return;
}

$query_args = array(
    'post_type'      => 'post',
    'post__in'       => $attributes['postIds'],
    'orderby'        => 'post__in',
    'posts_per_page' => 6,
);

$posts_query = new WP_Query( $query_args );

$columns_class = 'fp-grid-cols-' . intval( $attributes['columns'] );
?>

<div <?php echo get_block_wrapper_attributes( array( 'class' => 'featured-posts-frontend-grid ' . $columns_class ) ); ?>>
    <?php 
    if ( $posts_query->have_posts() ) : 
        while ( $posts_query->have_posts() ) : $posts_query->the_post(); ?>
            
            <article class="fp-post-card">
                
                <?php if ( ! empty( $attributes['showFeaturedImage'] ) && has_post_thumbnail() ) : ?>
                    <div class="fp-post-card-image">
                        <a href="<?php echo esc_url( get_permalink() ); ?>">
                            <?php the_post_thumbnail( 'medium' ); ?>
                        </a>
                    </div>
                <?php endif; ?>

                <div class="fp-post-card-body">
                    <h3 class="fp-post-card-title">
                        <a href="<?php echo esc_url( get_permalink() ); ?>">
                            <?php echo esc_html( get_the_title() ); ?>
                        </a>
                    </h3>

                    <?php if ( ! empty( $attributes['showExcerpt'] ) ) : ?>
                        <div class="fp-post-card-excerpt">
                            <?php 
                            echo wp_kses_post( get_the_excerpt() ); 
                            ?>
                        </div>
                    <?php endif; ?>
                </div>

            </article>

        <?php 
        endwhile;
        wp_reset_postdata(); // clean up
    endif; 
    ?>
</div>
