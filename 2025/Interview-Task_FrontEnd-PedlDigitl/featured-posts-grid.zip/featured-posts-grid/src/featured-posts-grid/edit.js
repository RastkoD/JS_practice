import { __ } from "@wordpress/i18n";
import { useBlockProps, InspectorControls } from "@wordpress/block-editor";
import {
	PanelBody,
	RangeControl,
	ToggleControl,
	FormTokenField,
} from "@wordpress/components";
import { useState, useEffect } from "@wordpress/element";
import apiFetch from "@wordpress/api-fetch";
import "./editor.scss";

export default function Edit({ attributes, setAttributes }) {
	const { postIds, columns, showExcerpt, showFeaturedImage } = attributes;
	const [posts, setPosts] = useState([]);

	useEffect(() => {
		apiFetch({ path: "/wp/v2/posts?per_page=12&status=publish" }).then(
			(data) => {
				setPosts(data);
			},
		);
	}, []);

	const suggestions = posts.map((p) => p.title.rendered);

	const selectedTokens = posts
		.filter((p) => postIds.includes(p.id))
		.map((p) => p.title.rendered);

	const handleTokenChange = (tokens) => {
		const limited = tokens.slice(0, 6);
		const ids = limited
			.map((token) => posts.find((p) => p.title.rendered === token)?.id)
			.filter(Boolean);
		setAttributes({ postIds: ids });
	};

	return (
		<div {...useBlockProps()}>
			<InspectorControls>
				<PanelBody title={__("Grid Settings", "featured-posts-grid")}>
					<RangeControl
						label={__("Columns", "featured-posts-grid")}
						value={columns}
						onChange={(val) => setAttributes({ columns: val })}
						min={2}
						max={3}
					/>
					<ToggleControl
						label={__("Show Featured Image", "featured-posts-grid")}
						checked={showFeaturedImage}
						onChange={(val) => setAttributes({ showFeaturedImage: val })}
					/>
					<ToggleControl
						label={__("Show Excerpt", "featured-posts-grid")}
						checked={showExcerpt}
						onChange={(val) => setAttributes({ showExcerpt: val })}
					/>
				</PanelBody>
			</InspectorControls>

			<div
				style={{
					border: "2px dashed #b5b5b5",
					padding: "20px",
					background: "#fff",
				}}
			>
				<p style={{ margin: "0 0 10px 0", fontWeight: "600" }}>
					{__("Select Featured Posts (max 6):", "featured-posts-grid")}
				</p>

				<FormTokenField
					value={selectedTokens}
					suggestions={suggestions}
					onChange={handleTokenChange}
					placeholder="Type a post title..."
				/>

				{postIds.length === 0 ? (
					<p style={{ marginTop: "20px", color: "#999", textAlign: "center" }}>
						{__("No posts selected yet.", "featured-posts-grid")}
					</p>
				) : (
					<div
						style={{
							display: "grid",
							gridTemplateColumns: `repeat(${columns}, 1fr)`,
							gap: "15px",
							marginTop: "20px",
						}}
					>
						{selectedTokens.map((title, i) => (
							<div
								key={i}
								style={{
									border: "1px solid #ddd",
									padding: "15px",
									background: "#f9f9f9",
								}}
							>
								{showFeaturedImage && (
									<div
										style={{
											background: "#ddd",
											height: "110px",
											marginBottom: "13px",
										}}
									/>
								)}
								<h4 style={{ margin: "0 0 8px 0" }}>{title}</h4>
								{showExcerpt && (
									<p style={{ margin: 0, fontSize: "13px", color: "#666" }}>
										Post excerpt will appear here...
									</p>
								)}
							</div>
						))}
					</div>
				)}
			</div>
		</div>
	);
}
