# Featured Posts Grid

## Build & Install

If installing from the zip, the `build/` folder is already included — just upload to `/wp-content/plugins/`, activate, and you're good to go.

To run from source:

1. Copy the folder into `/wp-content/plugins/`
2. Run `npm install`
3. Run `npm run build`
4. Activate the plugin in WordPress admin

## Decisions & Trade-offs

- **Post Selection:** Used `FormTokenField` with a pre-fetched list of 12 recent posts. Clean and simple for the scope of the task — on a larger site I'd replace this with a live REST API search on keystroke.
- **Editor Preview:** Images show as placeholders in the editor rather than fetching real thumbnails. The frontend is the source of truth, so I kept the editor lightweight.
- **Server-Side Rendering:** The block saves only post IDs and settings, never HTML. This means post content stays fresh automatically without needing to re-save the block.
- **Escaping:** All output runs through `esc_html()`, `esc_url()`, and `wp_kses_post()` as the brief asked for properly escaped HTML.
